//Product data:
			
	const productNames = ['digital camera','headset with microphone','wireless mouse'];
	const productNumbers = ['dc-25W','h-24 WFSD','wm-js-usb'];
	const productManPrices = [14.90,32.87,6.54];















